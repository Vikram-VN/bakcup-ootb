/* eslint-env node */
module.exports = require('@sugar-candy-framework/test/config.unit');
