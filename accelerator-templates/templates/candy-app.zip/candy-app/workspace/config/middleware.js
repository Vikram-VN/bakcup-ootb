module.exports = {
  fetch: {
    additionalForwardingHeaders: [
      // Header names list. The SCF server will read these headers from the
      // incoming requests and add them in requests to external services.
    ]
  }
};
