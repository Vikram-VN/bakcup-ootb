/**
 * Configuration file for the ESLint utility (https://eslint.org)
 */
/* eslint-env node */
module.exports = {
  extends: '@sugar-candy-framework/eslint-config/apps'
};
