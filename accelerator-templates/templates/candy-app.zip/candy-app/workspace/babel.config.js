/* eslint-env node */
module.exports = {
  extends: '@sugar-candy-framework/babel-config'
};
