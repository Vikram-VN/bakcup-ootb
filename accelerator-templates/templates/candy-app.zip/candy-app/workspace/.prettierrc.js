module.exports = {
  ...require('@sugar-candy-framework/prettier-config')
};
